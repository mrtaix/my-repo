/*
 * AntiCrash.h
 * Public interface — thường không cần import trực tiếp
 * vì dylib tự inject qua DYLD_INSERT_LIBRARIES hoặc được
 * link vào target thông qua Build Phases.
 */

#ifndef AntiCrash_h
#define AntiCrash_h

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Gọi hàm này nếu muốn khởi động thủ công thay vì dùng
 * __attribute__((constructor)) tự động.
 * Trong hầu hết trường hợp KHÔNG cần gọi — constructor tự chạy.
 */
void AntiCrashInstall(void);

#ifdef __cplusplus
}
#endif

#endif /* AntiCrash_h */
