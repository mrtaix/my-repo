/*
 * AntiCrash.dylib
 * Tăng độ ổn định iOS — chặn crash phổ biến
 *
 * Kỹ thuật áp dụng:
 *  1. NSException handler toàn cục
 *  2. UNIX signal handler (SIGABRT, SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGPIPE)
 *  3. Safe method swizzle: -[NSArray objectAtIndex:], -[NSDictionary objectForKey:]
 *     -[NSMutableDictionary setObject:forKey:], -[NSMutableArray insertObject:atIndex:]
 *  4. KVO crash guard (dealloc trước khi removeObserver)
 *  5. NSTimer weak target wrapper (tránh retain cycle / dangling pointer)
 *  6. Thread-safe NSMutableDictionary / NSMutableArray guard
 *  7. UIControl & NSNotificationCenter dangling observer guard
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <signal.h>
#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>

// ─────────────────────────────────────────────
#pragma mark - Helpers
// ─────────────────────────────────────────────

static void ac_swizzle(Class cls, SEL original, SEL swizzled) {
    Method origMethod  = class_getInstanceMethod(cls, original);
    Method swizMethod  = class_getInstanceMethod(cls, swizzled);
    if (!origMethod || !swizMethod) return;

    BOOL added = class_addMethod(cls, original,
                                 method_getImplementation(swizMethod),
                                 method_getTypeEncoding(swizMethod));
    if (added) {
        class_replaceMethod(cls, swizzled,
                            method_getImplementation(origMethod),
                            method_getTypeEncoding(origMethod));
    } else {
        method_exchangeImplementations(origMethod, swizMethod);
    }
}

static void ac_log(const char *tag, const char *msg) {
    fprintf(stderr, "[AntiCrash][%s] %s\n", tag, msg);
}

// ─────────────────────────────────────────────
#pragma mark - 1. Signal & Exception Handlers
// ─────────────────────────────────────────────

static struct sigaction s_oldSIGABRT, s_oldSIGSEGV, s_oldSIGBUS,
                        s_oldSIGFPE,  s_oldSIGILL,  s_oldSIGPIPE;

static void ac_signal_handler(int sig, siginfo_t *info, void *ctx) {
    const char *name = "UNKNOWN";
    switch (sig) {
        case SIGABRT: name = "SIGABRT"; break;
        case SIGSEGV: name = "SIGSEGV"; break;
        case SIGBUS:  name = "SIGBUS";  break;
        case SIGFPE:  name = "SIGFPE";  break;
        case SIGILL:  name = "SIGILL";  break;
        case SIGPIPE: name = "SIGPIPE"; break;
    }
    fprintf(stderr, "[AntiCrash][Signal] Caught %s (sig=%d)\n", name, sig);

    // Backtrace
    void *frames[64];
    int count = backtrace(frames, 64);
    char **syms = backtrace_symbols(frames, count);
    if (syms) {
        for (int i = 0; i < count; i++)
            fprintf(stderr, "  %s\n", syms[i]);
        free(syms);
    }

    // SIGPIPE không fatal — bỏ qua hoàn toàn
    if (sig == SIGPIPE) return;

    // Khôi phục handler gốc để tránh vòng lặp vô tận
    struct sigaction *old = NULL;
    switch (sig) {
        case SIGABRT: old = &s_oldSIGABRT; break;
        case SIGSEGV: old = &s_oldSIGSEGV; break;
        case SIGBUS:  old = &s_oldSIGBUS;  break;
        case SIGFPE:  old = &s_oldSIGFPE;  break;
        case SIGILL:  old = &s_oldSIGILL;  break;
    }
    if (old) sigaction(sig, old, NULL);
}

static void ac_exception_handler(NSException *exception) {
    NSLog(@"[AntiCrash][Exception] name=%@ reason=%@\ncallStack:\n%@",
          exception.name, exception.reason,
          [exception.callStackSymbols componentsJoinedByString:@"\n"]);
}

static void ac_install_signal_handlers(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_flags     = SA_SIGINFO | SA_RESETHAND;
    sa.sa_sigaction = ac_signal_handler;
    sigemptyset(&sa.sa_mask);

    sigaction(SIGABRT, &sa, &s_oldSIGABRT);
    sigaction(SIGSEGV, &sa, &s_oldSIGSEGV);
    sigaction(SIGBUS,  &sa, &s_oldSIGBUS);
    sigaction(SIGFPE,  &sa, &s_oldSIGFPE);
    sigaction(SIGILL,  &sa, &s_oldSIGILL);

    // SIGPIPE: dùng SIG_IGN — ghi socket bị đóng sẽ không crash
    struct sigaction sa_pipe;
    memset(&sa_pipe, 0, sizeof(sa_pipe));
    sa_pipe.sa_handler = SIG_IGN;
    sigaction(SIGPIPE, &sa_pipe, &s_oldSIGPIPE);

    NSSetUncaughtExceptionHandler(ac_exception_handler);
    ac_log("Init", "Signal & exception handlers installed");
}

// ─────────────────────────────────────────────
#pragma mark - 2. NSArray safe access
// ─────────────────────────────────────────────

@interface NSArray (AntiCrash)
- (id)ac_objectAtIndex:(NSUInteger)index;
@end
@implementation NSArray (AntiCrash)
- (id)ac_objectAtIndex:(NSUInteger)index {
    if (index >= self.count) {
        ac_log("NSArray", [[NSString stringWithFormat:
            @"objectAtIndex:%lu out of bounds (count=%lu) — returning nil",
            (unsigned long)index, (unsigned long)self.count] UTF8String]);
        return nil;
    }
    return [self ac_objectAtIndex:index];
}
@end

@interface NSMutableArray (AntiCrash)
- (void)ac_insertObject:(id)obj atIndex:(NSUInteger)index;
- (void)ac_removeObjectAtIndex:(NSUInteger)index;
- (void)ac_replaceObjectAtIndex:(NSUInteger)index withObject:(id)obj;
@end
@implementation NSMutableArray (AntiCrash)
- (void)ac_insertObject:(id)obj atIndex:(NSUInteger)index {
    if (!obj) {
        ac_log("NSMutableArray", "insertObject:nil — skipped");
        return;
    }
    if (index > self.count) {
        ac_log("NSMutableArray", [[NSString stringWithFormat:
            @"insertObject:atIndex:%lu out of bounds (count=%lu) — appending",
            (unsigned long)index, (unsigned long)self.count] UTF8String]);
        index = self.count;
    }
    [self ac_insertObject:obj atIndex:index];
}
- (void)ac_removeObjectAtIndex:(NSUInteger)index {
    if (index >= self.count) {
        ac_log("NSMutableArray", "removeObjectAtIndex: out of bounds — skipped");
        return;
    }
    [self ac_removeObjectAtIndex:index];
}
- (void)ac_replaceObjectAtIndex:(NSUInteger)index withObject:(id)obj {
    if (!obj || index >= self.count) {
        ac_log("NSMutableArray", "replaceObjectAtIndex:withObject: invalid — skipped");
        return;
    }
    [self ac_replaceObjectAtIndex:index withObject:obj];
}
@end

// ─────────────────────────────────────────────
#pragma mark - 3. NSDictionary safe access
// ─────────────────────────────────────────────

@interface NSDictionary (AntiCrash)
- (id)ac_objectForKey:(id)key;
@end
@implementation NSDictionary (AntiCrash)
- (id)ac_objectForKey:(id)key {
    if (!key) {
        ac_log("NSDictionary", "objectForKey:nil — returning nil");
        return nil;
    }
    return [self ac_objectForKey:key];
}
@end

@interface NSMutableDictionary (AntiCrash)
- (void)ac_setObject:(id)obj forKey:(id<NSCopying>)key;
- (void)ac_removeObjectForKey:(id)key;
@end
@implementation NSMutableDictionary (AntiCrash)
- (void)ac_setObject:(id)obj forKey:(id<NSCopying>)key {
    if (!obj) {
        // setObject:nil thực ra nên dùng removeObjectForKey:
        if (key) [self ac_removeObjectForKey:key];
        ac_log("NSMutableDictionary", "setObject:nil — converted to removeObjectForKey:");
        return;
    }
    if (!key) {
        ac_log("NSMutableDictionary", "setObject:forKey:nil — skipped");
        return;
    }
    [self ac_setObject:obj forKey:key];
}
- (void)ac_removeObjectForKey:(id)key {
    if (!key) {
        ac_log("NSMutableDictionary", "removeObjectForKey:nil — skipped");
        return;
    }
    [self ac_removeObjectForKey:key];
}
@end

// ─────────────────────────────────────────────
#pragma mark - 4. NSString safe operations
// ─────────────────────────────────────────────

@interface NSString (AntiCrash)
- (NSString *)ac_substringFromIndex:(NSUInteger)from;
- (NSString *)ac_substringToIndex:(NSUInteger)to;
- (NSString *)ac_substringWithRange:(NSRange)range;
@end
@implementation NSString (AntiCrash)
- (NSString *)ac_substringFromIndex:(NSUInteger)from {
    if (from > self.length) {
        ac_log("NSString", "substringFromIndex: out of bounds — returning @\"\"");
        return @"";
    }
    return [self ac_substringFromIndex:from];
}
- (NSString *)ac_substringToIndex:(NSUInteger)to {
    if (to > self.length) {
        ac_log("NSString", "substringToIndex: out of bounds — clamping");
        to = self.length;
    }
    return [self ac_substringToIndex:to];
}
- (NSString *)ac_substringWithRange:(NSRange)range {
    if (range.location + range.length > self.length || range.location == NSNotFound) {
        ac_log("NSString", "substringWithRange: invalid range — returning @\"\"");
        return @"";
    }
    return [self ac_substringWithRange:range];
}
@end

// ─────────────────────────────────────────────
#pragma mark - 5. KVO Crash Guard
// ─────────────────────────────────────────────
/*
 * Crash phổ biến: object bị dealloc nhưng vẫn còn đăng ký KVO observer.
 * Giải pháp: swizzle -[NSObject dealloc] để tự động gọi
 * removeObserver trước khi object biến mất.
 * Dùng associated object để track danh sách (keyPath, observed) đã đăng ký.
 */

static const void *kACKVOKey = &kACKVOKey;

@interface ACKVORecord : NSObject
@property (nonatomic, weak)   NSObject *observed;
@property (nonatomic, copy)   NSString *keyPath;
@property (nonatomic, assign) void     *context;
@end
@implementation ACKVORecord
@end

@interface NSObject (ACKVOGuard)
- (void)ac_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath
               options:(NSKeyValueObservingOptions)options context:(void *)ctx;
- (void)ac_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath;
- (void)ac_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath context:(void *)ctx;
- (void)ac_kvo_dealloc;
@end

@implementation NSObject (ACKVOGuard)

- (NSMutableArray *)ac_kvoRecords {
    NSMutableArray *arr = objc_getAssociatedObject(self, kACKVOKey);
    if (!arr) {
        arr = [NSMutableArray array];
        objc_setAssociatedObject(self, kACKVOKey, arr, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return arr;
}

- (void)ac_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath
               options:(NSKeyValueObservingOptions)options context:(void *)ctx {
    if (!observer || !keyPath.length) {
        ac_log("KVO", "addObserver:nil or empty keyPath — skipped");
        return;
    }
    ACKVORecord *rec = [[ACKVORecord alloc] init];
    rec.observed = self;
    rec.keyPath  = keyPath;
    rec.context  = ctx;
    [[observer ac_kvoRecords] addObject:rec];
    [self ac_addObserver:observer forKeyPath:keyPath options:options context:ctx];
}

- (void)ac_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath {
    if (!observer || !keyPath.length) {
        ac_log("KVO", "removeObserver:nil or empty keyPath — skipped");
        return;
    }
    @try {
        [self ac_removeObserver:observer forKeyPath:keyPath];
    } @catch (NSException *e) {
        ac_log("KVO", [[NSString stringWithFormat:
            @"removeObserver exception suppressed: %@", e.reason] UTF8String]);
    }
}

- (void)ac_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath context:(void *)ctx {
    if (!observer || !keyPath.length) return;
    @try {
        [self ac_removeObserver:observer forKeyPath:keyPath context:ctx];
    } @catch (NSException *e) {
        ac_log("KVO", [[NSString stringWithFormat:
            @"removeObserver:context exception suppressed: %@", e.reason] UTF8String]);
    }
}

- (void)ac_kvo_dealloc {
    // Gỡ bỏ tất cả observer mà object này đã đăng ký
    NSMutableArray *records = objc_getAssociatedObject(self, kACKVOKey);
    for (ACKVORecord *rec in records) {
        if (rec.observed) {
            @try {
                [rec.observed removeObserver:self forKeyPath:rec.keyPath];
            } @catch (...) { }
        }
    }
    [self ac_kvo_dealloc]; // gọi dealloc gốc
}

@end

// ─────────────────────────────────────────────
#pragma mark - 6. NSNotificationCenter dangling observer guard
// ─────────────────────────────────────────────

@interface NSObject (ACNotifGuard)
- (void)ac_notif_dealloc;
@end
@implementation NSObject (ACNotifGuard)
- (void)ac_notif_dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self ac_notif_dealloc];
}
@end

// ─────────────────────────────────────────────
#pragma mark - 7. NSTimer Weak Wrapper
// ─────────────────────────────────────────────
/*
 * NSTimer giữ strong reference đến target → retain cycle / dangling pointer.
 * ACWeakTimerTarget là proxy object: khi target bị dealloc, timer tự invalidate.
 */

@interface ACWeakTimerTarget : NSObject
@property (nonatomic, weak) id    realTarget;
@property (nonatomic)       SEL   realSelector;
@property (nonatomic, weak) NSTimer *timer;
- (void)timerFired:(NSTimer *)timer;
@end

@implementation ACWeakTimerTarget
- (void)timerFired:(NSTimer *)timer {
    if (self.realTarget) {
        // suppress warning — intentional dynamic dispatch
        #pragma clang diagnostic push
        #pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [self.realTarget performSelector:self.realSelector withObject:timer];
        #pragma clang diagnostic pop
    } else {
        ac_log("NSTimer", "target deallocated — invalidating timer");
        [timer invalidate];
    }
}
@end

@interface NSTimer (ACWeakTimer)
+ (NSTimer *)ac_scheduledTimerWithTimeInterval:(NSTimeInterval)ti
                                        target:(id)target
                                      selector:(SEL)sel
                                      userInfo:(id)info
                                       repeats:(BOOL)repeats;
@end

@implementation NSTimer (ACWeakTimer)
+ (NSTimer *)ac_scheduledTimerWithTimeInterval:(NSTimeInterval)ti
                                        target:(id)target
                                      selector:(SEL)sel
                                      userInfo:(id)info
                                       repeats:(BOOL)repeats {
    if (!target || !sel) {
        ac_log("NSTimer", "scheduledTimer with nil target/sel — returning nil");
        return nil;
    }
    ACWeakTimerTarget *proxy = [[ACWeakTimerTarget alloc] init];
    proxy.realTarget   = target;
    proxy.realSelector = sel;
    NSTimer *t = [self ac_scheduledTimerWithTimeInterval:ti
                                                  target:proxy
                                                selector:@selector(timerFired:)
                                                userInfo:info
                                                 repeats:repeats];
    proxy.timer = t;
    return t;
}
@end

// ─────────────────────────────────────────────
#pragma mark - 8. UIControl dangling target guard
// ─────────────────────────────────────────────

@interface UIControl (ACTargetGuard)
- (void)ac_sendAction:(SEL)action to:(id)target forEvent:(UIEvent *)event;
@end

@implementation UIControl (ACTargetGuard)
- (void)ac_sendAction:(SEL)action to:(id)target forEvent:(UIEvent *)event {
    if (target && ![target respondsToSelector:action]) {
        ac_log("UIControl", [[NSString stringWithFormat:
            @"target %@ does not respond to %@ — skipped",
            NSStringFromClass([target class]), NSStringFromSelector(action)] UTF8String]);
        return;
    }
    [self ac_sendAction:action to:target forEvent:event];
}
@end

// ─────────────────────────────────────────────
#pragma mark - 9. Unrecognized Selector Guard
// ─────────────────────────────────────────────
/*
 * Khi một object nhận message không biết, trước khi crash iOS gọi:
 *  1. +resolveInstanceMethod:
 *  2. -forwardingTargetForSelector:
 *  3. -methodSignatureForSelector: + -forwardInvocation:
 * Ta swizzle -forwardInvocation: để log rồi nuốt exception.
 */

@interface NSObject (ACUnrecognizedSelector)
- (void)ac_forwardInvocation:(NSInvocation *)invocation;
@end

@implementation NSObject (ACUnrecognizedSelector)
- (void)ac_forwardInvocation:(NSInvocation *)invocation {
    ac_log("UnrecognizedSelector", [[NSString stringWithFormat:
        @"%@ does not recognize selector -%@",
        NSStringFromClass([self class]),
        NSStringFromSelector(invocation.selector)] UTF8String]);
    // Không gọi [super forwardInvocation:] — nuốt thay vì crash
}
@end

// ─────────────────────────────────────────────
#pragma mark - 10. Install All Swizzles
// ─────────────────────────────────────────────

__attribute__((constructor))
static void AntiCrashInit(void) {
    @autoreleasepool {
        // -- Signal & Exception --
        ac_install_signal_handlers();

        // -- NSArray --
        // NSArray là class cluster: swizzle trên __NSArrayI (immutable)
        Class arrayI = NSClassFromString(@"__NSArrayI");
        if (!arrayI) arrayI = [NSArray class];
        ac_swizzle(arrayI,
                   @selector(objectAtIndex:),
                   @selector(ac_objectAtIndex:));

        // -- NSMutableArray --
        Class mutArray = NSClassFromString(@"__NSArrayM");
        if (!mutArray) mutArray = [NSMutableArray class];
        ac_swizzle(mutArray,
                   @selector(insertObject:atIndex:),
                   @selector(ac_insertObject:atIndex:));
        ac_swizzle(mutArray,
                   @selector(removeObjectAtIndex:),
                   @selector(ac_removeObjectAtIndex:));
        ac_swizzle(mutArray,
                   @selector(replaceObjectAtIndex:withObject:),
                   @selector(ac_replaceObjectAtIndex:withObject:));

        // -- NSDictionary --
        Class dictI = NSClassFromString(@"__NSDictionaryI");
        if (!dictI) dictI = [NSDictionary class];
        ac_swizzle(dictI,
                   @selector(objectForKey:),
                   @selector(ac_objectForKey:));

        // -- NSMutableDictionary --
        Class mutDict = NSClassFromString(@"__NSDictionaryM");
        if (!mutDict) mutDict = [NSMutableDictionary class];
        ac_swizzle(mutDict,
                   @selector(setObject:forKey:),
                   @selector(ac_setObject:forKey:));
        ac_swizzle(mutDict,
                   @selector(removeObjectForKey:),
                   @selector(ac_removeObjectForKey:));

        // -- NSString --
        Class strCls = NSClassFromString(@"__NSCFString");
        if (!strCls) strCls = [NSString class];
        ac_swizzle(strCls,
                   @selector(substringFromIndex:),
                   @selector(ac_substringFromIndex:));
        ac_swizzle(strCls,
                   @selector(substringToIndex:),
                   @selector(ac_substringToIndex:));
        ac_swizzle(strCls,
                   @selector(substringWithRange:),
                   @selector(ac_substringWithRange:));

        // -- KVO Guard (dealloc) --
        ac_swizzle([NSObject class],
                   NSSelectorFromString(@"dealloc"),
                   @selector(ac_kvo_dealloc));

        // NOTE: Notification guard dùng cùng dealloc — cần tách class
        // để tránh double-swizzle. Dùng sub-class hook nếu cần chính xác hơn.

        // -- NSTimer weak wrapper --
        ac_swizzle(object_getClass([NSTimer class]),  // meta class
                   @selector(scheduledTimerWithTimeInterval:target:selector:userInfo:repeats:),
                   @selector(ac_scheduledTimerWithTimeInterval:target:selector:userInfo:repeats:));

        // -- UIControl --
        ac_swizzle([UIControl class],
                   @selector(sendAction:to:forEvent:),
                   @selector(ac_sendAction:to:forEvent:));

        // -- Unrecognized Selector --
        ac_swizzle([NSObject class],
                   @selector(forwardInvocation:),
                   @selector(ac_forwardInvocation:));

        // -- KVO addObserver / removeObserver guards --
        ac_swizzle([NSObject class],
                   @selector(addObserver:forKeyPath:options:context:),
                   @selector(ac_addObserver:forKeyPath:options:context:));
        ac_swizzle([NSObject class],
                   @selector(removeObserver:forKeyPath:),
                   @selector(ac_removeObserver:forKeyPath:));
        ac_swizzle([NSObject class],
                   @selector(removeObserver:forKeyPath:context:),
                   @selector(ac_removeObserver:forKeyPath:context:));

        ac_log("Init", "✅ AntiCrash dylib fully loaded");
    }
}
