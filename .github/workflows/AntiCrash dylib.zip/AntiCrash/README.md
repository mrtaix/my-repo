# AntiCrash.dylib — iOS Stability Booster

Dylib chặn các loại crash phổ biến nhất trên iOS thông qua method swizzling và signal handling. Tương thích iOS 12+, arm64 / arm64e.

---

## Danh sách crash được bảo vệ

| # | Loại crash | Kỹ thuật |
|---|-----------|----------|
| 1 | SIGABRT / SIGSEGV / SIGBUS / SIGFPE / SIGILL | UNIX signal handler + backtrace |
| 2 | SIGPIPE (socket bị đóng) | `SIG_IGN` — bỏ qua hoàn toàn |
| 3 | NSException chưa bắt | `NSSetUncaughtExceptionHandler` |
| 4 | `NSArray objectAtIndex:` out of bounds | Swizzle → trả `nil` |
| 5 | `NSMutableArray insertObject:nil` / out of bounds | Swizzle → skip / clamp |
| 6 | `NSDictionary objectForKey:nil` | Swizzle → trả `nil` |
| 7 | `NSMutableDictionary setObject:nil forKey:` | Swizzle → `removeObjectForKey:` |
| 8 | `NSString substringFromIndex/ToIndex/WithRange:` out of bounds | Swizzle → trả `@""` |
| 9 | KVO: dealloc trước khi removeObserver | Swizzle `dealloc` + auto-remove |
| 10 | KVO: `removeObserver` khi không đăng ký | `@try/@catch` suppress |
| 11 | `NSNotificationCenter` dangling observer | Auto `removeObserver:self` trong dealloc |
| 12 | `NSTimer` retain cycle / dangling target | Weak proxy `ACWeakTimerTarget` |
| 13 | `UIControl` gửi action đến target không respond | Swizzle `sendAction:to:forEvent:` |
| 14 | Unrecognized selector crash | Swizzle `forwardInvocation:` → nuốt |

---

## Build (macOS + Xcode)

```bash
# Clone / copy project
cd AntiCrash

# Build fat binary arm64 + arm64e
make

# Output: build/AntiCrash.dylib
```

---

## Cách tích hợp

### A. Nhúng vào Xcode project

1. Kéo `AntiCrash.dylib` vào **Frameworks, Libraries, and Embedded Content**
2. Đặt thành **Embed & Sign**
3. Không cần `#import` — `__attribute__((constructor))` tự chạy khi dylib load

### B. Inject qua DYLD (simulator / jailbreak dev)

```bash
DYLD_INSERT_LIBRARIES=/path/to/AntiCrash.dylib /path/to/app.app/app
```

### C. MobileSubstrate / Theos tweak (jailbreak)

```bash
# Copy Makefile.theos → Makefile (hoặc dùng song song)
cp Makefile.theos Makefile
make package install   # cần THEOS_DEVICE_IP đã set
```

File `.plist` filter (để inject vào app cụ thể):

```xml
<!-- AntiCrash.plist -->
{ Filter = { Bundles = ( "com.target.app.bundle" ); }; }
```

---

## Cấu hình / tuỳ chỉnh

Tất cả log được ghi qua `stderr` với prefix `[AntiCrash][tag]`.
Xem trong Console.app hoặc:

```bash
idevicesyslog | grep AntiCrash
```

Để **tắt log** trong bản production, thêm vào `CFLAGS`:

```
-DAC_SILENT
```

Rồi bọc `ac_log(...)` trong:

```c
#ifndef AC_SILENT
static void ac_log(...) { ... }
#else
#define ac_log(tag, msg) ((void)0)
#endif
```

---

## Lưu ý quan trọng

- **App Store**: Dylib embedding được App Store chấp nhận nếu signed đúng.  
  Swizzle các class Apple là kỹ thuật hợp lệ (không vi phạm private API).
- **Không thay thế bug fix**: Dylib này *chặn crash* để tăng UX, không phải lý do để bỏ qua việc sửa bug gốc.
- **Thread safety**: Các guard hiện tại không thêm lock cho collection operations — nếu app dùng concurrent access nặng, cân nhắc thêm `@synchronized` hoặc dùng serial dispatch queue.
- **Swift compatibility**: Swizzle chỉ hoạt động với Objective-C runtime. Swift class thuần (không `@objc`) không bị ảnh hưởng.

---

## Cấu trúc file

```
AntiCrash/
├── AntiCrash.m      ← Toàn bộ implementation
├── AntiCrash.h      ← Public header (optional)
├── Makefile         ← Build với Xcode clang
├── Makefile.theos   ← Build với Theos
└── README.md
```
